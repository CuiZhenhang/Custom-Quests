ConfigureMultiplayer({
	isClientOnly: false
});
Launch();