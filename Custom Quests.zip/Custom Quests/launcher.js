ConfigureMultiplayer({
    name: "Custom Quests",
    version: "beta_1.2.0",
    isClientOnly: false
});
Launch();